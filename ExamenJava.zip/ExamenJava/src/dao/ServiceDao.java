/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Service;

/**
 *
 * @author Foumilayo
 */
public class ServiceDao implements IDao<Service>{
     private final String SQL_SELECT_ALL_SERVICES = "SELECT * FROM `service`";
      private final String SQL_INSERT_SERVICE = "INSERT INTO `service`( `libelle`) VALUES (?)";
      
          private BasedonneeDao daoMysql;
    private final BasedonneeDao basedonneeDao;
          
          public ServiceDao() {
        this.basedonneeDao = new BasedonneeDao();
    }
          
          @Override
    public Service add(Service service) {
        try {
            basedonneeDao.getConnection();
            basedonneeDao.initPS(SQL_INSERT_SERVICE);
            
            PreparedStatement ps =daoMysql.getPstm();
            ps.setString(1, service.getLibelle());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if(rs.next()){
                int id = rs.getInt(1);
                service.setIdService(id);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            basedonneeDao.CloseConnection();
        }
        
        return service;
    }
    
     @Override
    public List<Service> selectAll() {
         try {
             basedonneeDao.getConnection();
         } catch (SQLException ex) {
             Logger.getLogger(ServiceDao.class.getName()).log(Level.SEVERE, null, ex);
         }
        List<Service> services = new ArrayList<>();
         try {
             basedonneeDao.initPS(SQL_SELECT_ALL_SERVICES);
         } catch (SQLException ex) {
             Logger.getLogger(ServiceDao.class.getName()).log(Level.SEVERE, null, ex);
         }
        try {
            PreparedStatement ps =basedonneeDao.getPstm();
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                     Service service = new Service();
                     service.setIdService(rs.getInt("id_service"));
                service.setLibelle(rs.getString("libelle"));
                
                services.add(service);
                    
                }
                
            
        } catch(SQLException ex) {
            Logger.getLogger(ServiceDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            basedonneeDao.CloseConnection();
        }
        
        return services;
    }
    
}
