/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Foumilayo
 */
public class BasedonneeDao {
    private Connection cnx;
    private PreparedStatement pstm;
    private int ok;
    private ResultSet rs;
    
    public void getConnection() throws SQLException{
        cnx = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            cnx = DriverManager.getConnection("jdbc:mysql://localhost:3306/examen_java", "root", "");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BasedonneeDao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(BasedonneeDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void initPS(String sql) throws SQLException{
            getConnection();
            try{
                if(sql.toLowerCase().startsWith("insert")){
                    pstm = cnx.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                } else {
                    pstm = cnx.prepareStatement(sql);
                }
            } catch(SQLException ex){
                Logger.getLogger(BasedonneeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    public void CloseConnection(){
        try{
            if(cnx!=null){
                cnx.close();
            }
        } catch(SQLException ex){
            Logger.getLogger(BasedonneeDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    PreparedStatement getPstm() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
