/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Employe;
import models.Service;

/**
 *
 * @author Foumilayo
 */
public class IEmployeDao implements IDao<Employe>{
    
    private final String SQL_SELECT_ALL_EMPLOYES = "SELECT * FROM `employe` INNER JOIN service on employe.id_service=service.id_service";
    private final String SQL_SELECT_EMPLOYES_OF_SERVICE = "SELECT * FROM `employe` INNER JOIN service on employe.id_service=service.id_service WHERE `id_service`=?";
    private final String SQL_INSERT_EMPLOYE = "INSERT INTO `employe`(`nom_complet`, `date_embauche`, `id_service`) VALUES (?,?,?)";
   
   
    
    private BasedonneeDao basedonneeDao;

   
    
 public IEmployeDao() {
        this.basedonneeDao = new BasedonneeDao();
    }

    @Override
    public Employe add(Employe employe) {
        try {
            basedonneeDao.getConnection();
            basedonneeDao.initPS(SQL_INSERT_EMPLOYE);
            
            PreparedStatement ps =basedonneeDao.getPstm();
            ps.setString(1, employe.getNomComplet());
            ps.setString(2, employe.getDateEmbauche().toString());
            ps.setInt(3, employe.getService().getIdService());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if(rs.next()){
                int id = rs.getInt(1);
                employe.setId(id);
            }
        } catch (SQLException ex) {
            Logger.getLogger(IEmployeDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            basedonneeDao.CloseConnection();
        }
        
        return employe;
}
@Override
    public List<Employe> selectAll() {
        try {
            basedonneeDao.getConnection();
        } catch (SQLException ex) {
            Logger.getLogger(IEmployeDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        List<Employe> employes = new ArrayList<>();
        try {
            basedonneeDao.initPS(SQL_SELECT_ALL_EMPLOYES);
        } catch (SQLException ex) {
            Logger.getLogger(IEmployeDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            PreparedStatement ps =basedonneeDao.getPstm();
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Employe employe = new Employe();
                employe.setId(rs.getInt("id_employe"));
                employe.setNomComplet(rs.getString("nom_complet"));
                employe.setDateEmbauche(LocalDate.parse(rs.getString("date_embauche"), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                employe.setService(new Service(rs.getInt("id_service"), rs.getString("libelle")));
                employes.add(employe);
            } 
        } catch(SQLException ex) {
            Logger.getLogger(IEmployeDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            basedonneeDao.CloseConnection();
        }
        
        return employes; 
    }

    }
