/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import dao.ServiceDao;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.paint.Color;
import models.Employe;
import models.Service;
import services.ServiceService;

/**
 * FXML Controller class
 *
 * @author Foumilayo
 */
public class FrmServiceController implements Initializable {

   private Service serviceToAdd;
   ObservableList<String> serviceList;
   
    @FXML
    private Label serviceTextFieldLabel1;
     @FXML
     @FXML
    private JFXButton createServiceButton;
    private JFXTextField nameserviceTextField1;
     @FXML
      private TableView<Service> tblv1;
    @FXML
    private TableColumn<Service, String> nameTblc1;
    
    private Label servErrorLbl;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        ServiceDao dao = new ServiceDao();
       ServiceService serviceService = new ServiceService();
        serviceList = FXCollections.observableArrayList(ServiceService.comboBoxCategoryListToString(dao.selectAll()));
        // TODO
    }   
     @FXML
    private void createService(ActionEvent event) {
        serviceToAdd = new Service(nameserviceTextField1.getText());
        serviceService.add(serviceToAdd);
        serviceList.add(serviceToAdd.getLibelle());
        
        servErrorLbl.setTextFill(Color.GREEN);
        servErrorLbl.setText("Création réussie");
    }
    
}
