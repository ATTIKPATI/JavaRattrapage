/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import dao.IEmployeDao;
import dao.ServiceDao;
import java.util.List;
import java.util.ListIterator;
import models.Employe;
import models.Service;

/**
 *
 * @author Foumilayo
 */
public class ServiceService {
     private ServiceDao serviceDao;
    private IEmployeDao employeDao;
    
    public ServiceService() {
        serviceDao = new ServiceDao();
        employeDao = new IEmployeDao();
    }
     public Employe affecterEmployerInService(Employe employe, Service service){
        service.getEmployes().add(employe);
        employe.setService(service);
        employeDao.add(employe);
        return employe;
    }
     public Service add(Service service){
        return serviceDao.add(service);
    }
public List<Service> list(){
        return serviceDao.selectAll();
    }
public Service printSpecific(String value){
        ListIterator<Service> li = list().listIterator();
        Service service = null;
        while (li.hasNext()) {
            service = li.next();
            if (service.getLibelle().equals(value))
                return service;
        }
        return service;
    }
}
