/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import dao.IEmployeDao;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import models.Employe;

/**
 *
 * @author Foumilayo
 */
public class EmployeService  {
     private IEmployeDao dao;
    
    public EmployeService() {
        dao = new IEmployeDao();
    }
     public List<Employe> list(){
        return dao.selectAll();
    }
     public List<Employe> affichage() {
        ListIterator<Employe> li = list().listIterator();
        List<Employe> employes = new ArrayList();
        Employe emp = null;
        
        return employes;
    }
}
