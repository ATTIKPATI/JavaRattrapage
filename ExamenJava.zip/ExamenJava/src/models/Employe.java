/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.security.Provider.Service;
import java.time.LocalDate;

/**
 *
 * @author Foumilayo
 */
public class Employe {
    private int id;
    private String nomComplet;
    private LocalDate dateEmbauche;
    
    private Service service;
    
    public Employe(){
}
    public Employe(int id, String nomComplet, LocalDate dateEmbauche){
        this.id = id;
        this.nomComplet = nomComplet;
        this.dateEmbauche = dateEmbauche;
}
    public Employe(String nomComplet, LocalDate dateEmbauche) {
        this.nomComplet = nomComplet;
        this.dateEmbauche = dateEmbauche;
    }
    
     public int getIdEmploye() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
     public String getNomComplet() {
        return nomComplet;
    }

    public void setNomComplet(String nomComplet) {
        this.nomComplet = nomComplet;
    }
    public LocalDate getDateEmbauche() {
        return dateEmbauche;
    }

    public void setDateEmbauche(LocalDate dateEmbauche) {
        this.dateEmbauche = dateEmbauche;
    }
    public Service getService() {
        return service;
    }

    public void setService(Service service) {
        this.service = service;
    }

    @Override
    public String toString() {
        return "Employe{" + "id=" + id + ", nomComplet=" + nomComplet + ", dateEmbauche=" + dateEmbauche + ", service=" + service + '}';
    }
    
}
